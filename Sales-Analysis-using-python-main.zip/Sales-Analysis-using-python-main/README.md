# Sales-Analysis-using-python
I analyzed 4 years of sales data using Python Pandas for data manipulation and Matplotlib for visualization. The project answered key business questions, such as overall sales trends, top-selling products, and preferred shipping modes.

We have answered these 5 questions through our data analysis mainly using pandas and matplotlib library.

Q1. What is the overall sales trend? <br>
Q2. Which are the Top 10 products by sales?<br>
Q3. Which are the Most Selling Products?<br>
Q4. Which is the most preferred Ship Mode?<br>
Q5. Which are the Most Profitable Category and Sub-Category?
